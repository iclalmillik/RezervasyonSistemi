﻿namespace ProLab
{
    partial class Arac
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AraclariGoruntule = new ListBox();
            label1 = new Label();
            textIdekle = new TextBox();
            textyolcusayisi = new TextBox();
            label4 = new Label();
            textyakit = new TextBox();
            label2 = new Label();
            textsilId = new TextBox();
            label3 = new Label();
            butonaracekle = new Button();
            buttonaracsil = new Button();
            SeferleriGoruntule = new ListBox();
            SuspendLayout();
            // 
            // AraclariGoruntule
            // 
            AraclariGoruntule.FormattingEnabled = true;
            AraclariGoruntule.ItemHeight = 20;
            AraclariGoruntule.Location = new Point(15, 7);
            AraclariGoruntule.Name = "AraclariGoruntule";
            AraclariGoruntule.Size = new Size(434, 424);
            AraclariGoruntule.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(499, 47);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 1;
            label1.Text = "Araç ID";
            // 
            // textIdekle
            // 
            textIdekle.Location = new Point(657, 47);
            textIdekle.Name = "textIdekle";
            textIdekle.Size = new Size(125, 27);
            textIdekle.TabIndex = 2;
            // 
            // textyolcusayisi
            // 
            textyolcusayisi.Location = new Point(657, 158);
            textyolcusayisi.Name = "textyolcusayisi";
            textyolcusayisi.Size = new Size(125, 27);
            textyolcusayisi.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(499, 165);
            label4.Name = "label4";
            label4.Size = new Size(85, 20);
            label4.TabIndex = 7;
            label4.Text = "Yolcu Sayısı";
            // 
            // textyakit
            // 
            textyakit.Location = new Point(657, 103);
            textyakit.Name = "textyakit";
            textyakit.Size = new Size(125, 27);
            textyakit.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(499, 110);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 9;
            label2.Text = "Yakıt Türü";
            // 
            // textsilId
            // 
            textsilId.Location = new Point(623, 327);
            textsilId.Name = "textsilId";
            textsilId.Size = new Size(125, 27);
            textsilId.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(514, 330);
            label3.Name = "label3";
            label3.Size = new Size(58, 20);
            label3.TabIndex = 11;
            label3.Text = "Arac ID";
            // 
            // butonaracekle
            // 
            butonaracekle.Location = new Point(556, 230);
            butonaracekle.Name = "butonaracekle";
            butonaracekle.Size = new Size(94, 29);
            butonaracekle.TabIndex = 13;
            butonaracekle.Text = "Ekle";
            butonaracekle.UseVisualStyleBackColor = true;
            butonaracekle.Click += butonaracekle_Click;
            // 
            // buttonaracsil
            // 
            buttonaracsil.Location = new Point(556, 387);
            buttonaracsil.Name = "buttonaracsil";
            buttonaracsil.Size = new Size(94, 29);
            buttonaracsil.TabIndex = 14;
            buttonaracsil.Text = "Sil";
            buttonaracsil.UseVisualStyleBackColor = true;
            buttonaracsil.Click += buttonaracsil_Click;
            // 
            // SeferleriGoruntule
            // 
            SeferleriGoruntule.FormattingEnabled = true;
            SeferleriGoruntule.ItemHeight = 20;
            SeferleriGoruntule.Location = new Point(997, 14);
            SeferleriGoruntule.Name = "SeferleriGoruntule";
            SeferleriGoruntule.Size = new Size(471, 424);
            SeferleriGoruntule.TabIndex = 15;
            SeferleriGoruntule.SelectedIndexChanged += SeferleriGoruntule_SelectedIndexChanged;
            // 
            // Arac
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1480, 450);
            Controls.Add(SeferleriGoruntule);
            Controls.Add(buttonaracsil);
            Controls.Add(butonaracekle);
            Controls.Add(textsilId);
            Controls.Add(label3);
            Controls.Add(textyakit);
            Controls.Add(label2);
            Controls.Add(textyolcusayisi);
            Controls.Add(label4);
            Controls.Add(textIdekle);
            Controls.Add(label1);
            Controls.Add(AraclariGoruntule);
            Name = "Arac";
            Text = "FirmaPaneli";
            Load += Arac_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox AraclariGoruntule;
        private Label label1;
        private TextBox textIdekle;
        private TextBox textyolcusayisi;
        private Label label4;
        private TextBox textyakit;
        private Label label2;
        private TextBox textsilId;
        private Label label3;
        private Button butonaracekle;
        private Button buttonaracsil;
        private ListBox SeferleriGoruntule;
    }
}