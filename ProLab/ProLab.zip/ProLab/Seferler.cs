﻿using System;
using System.Collections.Generic;

namespace ProLab
{
    public class Seferler
    {
        public string SeferNo { get; set; }
        public string UlastirmaTuru { get; set; }
        public string KalkisNoktasi { get; set; }
        public string VarisNoktasi { get; set; }
        public DateTime Tarih { get; set; }

         List<Seferler> SeferlerListesi = new List<Seferler>();

        public Seferler(string seferNo, string ulasimTuru, string kalkisNoktasi, string varisNoktasi, DateTime tarih)
        {
            SeferNo = seferNo;
            UlastirmaTuru = ulasimTuru;
            KalkisNoktasi = kalkisNoktasi;
            VarisNoktasi = varisNoktasi;
            Tarih = tarih;

        }

        public Seferler()
        {
        }

        public void SeferleriOlustur()
        {
            SeferlerListesi.Add(new Seferler("1", "Demiryolu", "İstanbul", "Kocaeli", new DateTime(2023, 12, 3)));
            SeferlerListesi.Add(new Seferler("2", "Demiryolu", "İstanbul", "Bilecik", new DateTime(2023, 12, 4)));
            SeferlerListesi.Add(new Seferler("3", "Karayolu", "İstanbul", "Ankara", new DateTime(2023, 12, 5)));
            SeferlerListesi.Add(new Seferler("4", "Karayolu", "Ankara", "İstanbul", new DateTime(2023, 12, 6)));
            SeferlerListesi.Add(new Seferler("5", "Havayolu", "İstanbul", "Konya", new DateTime(2023, 12, 7)));
            SeferlerListesi.Add(new Seferler("6", "Havayolu", "İstanbul", "Ankara", new DateTime(2023, 12, 8)));
        }
    }
}
