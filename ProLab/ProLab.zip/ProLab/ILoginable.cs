﻿namespace Prolab2_1.deneme
{
    public interface ILoginable
    {
        string Sifre { get; }
    }
}