﻿using ProLab;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static ProLab.Araclar;
using static ProLab.Seferler;

namespace ProLab
{
    public partial class Arac : Form
    {
        public List<Araclar> tasit;
        public Arac()
        {
            InitializeComponent();
        }

        public Arac(List<Araclar> tasit)
        {
            InitializeComponent();

            this.tasit = tasit ?? new List<Araclar>();
            AraclariGoruntule.DataSource = this.tasit;
            AraclariGoruntule.DisplayMember = "id;yakit_turu;yolcu_sayisi";
        }


        private void butonaracekle_Click(object sender, EventArgs e)
        {
            string eklenecekId = textIdekle.Text;
            string yakitturu = textyakit.Text;
            string yolcusayisi = textyolcusayisi.Text;


            ConcreteClassA yeniArac = new ConcreteClassA(id: eklenecekId, yakit_turu: yakitturu, yolcu_sayisi: yolcusayisi);


            tasit.Add(yeniArac);

            AraclariGoruntule.DataSource = null;
            AraclariGoruntule.DataSource = tasit;
            AraclariGoruntule.DisplayMember = "id;yakit_turu;yolcu_sayisi";

            textIdekle.Clear();
            textyakit.Clear();
            textyolcusayisi.Clear();
        }

        private void buttonaracsil_Click(object sender, EventArgs e)
        {
            string silinecekAracId = textsilId.Text;


            Araclar silinecekArac = tasit.Find(arac => arac.id == silinecekAracId);

            if (silinecekArac != null)
            {

                tasit.Remove(silinecekArac);


                AraclariGoruntule.DataSource = null;
                AraclariGoruntule.DataSource = tasit;
                AraclariGoruntule.DisplayMember = "id;yakit_turu;yolcu_sayisi";
            }
            else
            {
                MessageBox.Show("Silinecek araç bulunamadı.");
            }

            textsilId.Clear();


        }

        private void SeferleriGoruntule_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

       
    }
}

public class YeniSinif : Form
{
    List<Seferler> SeferListesi = new List<Seferler>();

    public YeniSinif()
    {

    }
    public YeniSinif(List<Seferler> seferlerListesi)
    {
        SeferListesi.Add(new Seferler("1", "Demiryolu", "İstanbul", "Kocaeli", new DateTime(2023, 12, 3)));
        SeferListesi.Add(new Seferler("2", "Demiryolu", "İstanbul", "Bilecik", new DateTime(2023, 12, 4)));
        SeferListesi.Add(new Seferler("3", "Karayolu", "İstanbul", "Ankara", new DateTime(2023, 12, 5)));
        SeferListesi.Add(new Seferler("4", "Karayolu", "Ankara", "İstanbul", new DateTime(2023, 12, 6)));
        SeferListesi.Add(new Seferler("5", "Havayolu", "İstanbul", "Konya", new DateTime(2023, 12, 8)));




    }
    private void YeniSinif_Load(object sender, EventArgs e)
    {

        this.Seferler = SeferlerListesi ?? new List<Seferler>();
        SeferleriGoruntule.DataSource = this.Sefer;
        SeferleriGoruntule.DisplayMember = "SeferNo ;UlastirmaTuru;KalkisNoktasi; VarisNoktasi;Tarih";

    }
}


